Depot & Atelier — Android APK Project

هذا مجلد مشروع Android Studio جاهز للبناء.

طريقة إنشاء APK:
1. ثبّت Android Studio.
2. فك ضغط DepotAtelier-Android.zip.
3. من Android Studio اختر Open وافتح مجلد DepotAtelier-Android.
4. انتظر انتهاء Gradle Sync.
5. اختر Build > Build APK(s).
6. ستجد ملف APK داخل:
   app/build/outputs/apk/debug/app-debug.apk

لنسخة Release:
Build > Generate Signed App Bundle / APK > APK
ثم أنشئ مفتاح توقيع واتبع الخطوات.

التطبيق يعمل بدون إنترنت لأن ملف HTML موجود داخل APK.
بيانات المخزون محفوظة محلياً داخل التطبيق.
لا توجد خيارات Backup أو Reset في الواجهة.
